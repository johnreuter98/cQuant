import pandas as pd
import numpy as np
import matplotlib as mp

#reading in data and placing it all into one csv
priceDataDf16 = pd.read_csv('C:\\Users\\jmreu\\OneDrive\\Desktop\\cQuant Exam\\cQuantExam\\ERCOT_DA_Prices_2016.csv',parse_dates=['Date'],index_col='Date')
priceDataDf17 = pd.read_csv('C:\\Users\\jmreu\\OneDrive\\Desktop\\cQuant Exam\\cQuantExam\\ERCOT_DA_Prices_2017.csv',parse_dates=['Date'],index_col='Date')
priceDataDf18 = pd.read_csv('C:\\Users\\jmreu\\OneDrive\\Desktop\\cQuant Exam\\cQuantExam\\ERCOT_DA_Prices_2018.csv',parse_dates=['Date'],index_col='Date')
priceDataDf19 = pd.read_csv('C:\\Users\\jmreu\\OneDrive\\Desktop\\cQuant Exam\\cQuantExam\\ERCOT_DA_Prices_2019.csv',parse_dates=['Date'],index_col='Date')
priceDataDf = pd.concat([priceDataDf16,priceDataDf17,priceDataDf18,priceDataDf19])

#finding averages
monthAvgDf = priceDataDf.groupby(['SettlementPoint',pd.Grouper(freq='ME')]).mean('Price')

#splitting the datetime index into just month and year
monthAvgDf = monthAvgDf.reset_index()
monthAvgDf['Month'] = monthAvgDf['Date'].dt.month
monthAvgDf['Year'] = monthAvgDf['Date'].dt.year
monthAvgDf = monthAvgDf.drop('Date',axis=1)

#writing to the output csv
pd.DataFrame.to_csv(monthAvgDf, 'C:\\Users\\jmreu\\OneDrive\\Desktop\\cQuant Exam\\cQuantExam\\AveragePriceByMonth.csv', index=False)

#filtering data for price volatililty
volFilteredDf = priceDataDf[priceDataDf['SettlementPoint'].str.contains('HB_')]
volFilteredDf = volFilteredDf[volFilteredDf['Price'] > 0]

#finding the log returns
volFilteredDf['LogReturn'] = np.log(volFilteredDf['Price'])
volFilteredDf = volFilteredDf.drop('Price', axis=1)

#filtering to the sd of the log returns per year and settlement hub
yearVol = volFilteredDf.groupby(['SettlementPoint',pd.Grouper(freq='YE')]).std(1,numeric_only=True)

#splitting the datetime index into just year and renaming the columns to the requested names
yearVol = yearVol.reset_index()
yearVol['Year'] = yearVol['Date'].dt.year
yearVol = yearVol.drop('Date',axis=1)
yearVol = yearVol.rename(columns={'LogReturn':'HourlyVolatility'})

#writing to the output csv
pd.DataFrame.to_csv(yearVol, 'C:\\Users\\jmreu\\OneDrive\\Desktop\\cQuant Exam\\cQuantExam\\HourlyVolatilityByYear.csv', index=False)

#finding the maximum hourly volatilities
maxVol = yearVol.groupby('Year').max()

#writing to the output csv
pd.DataFrame.to_csv(maxVol, 'C:\\Users\\jmreu\\OneDrive\\Desktop\\cQuant Exam\\cQuantExam\\MaxVolatilityByYear.csv', index=False)

#sorting data
sortedDf = priceDataDf.reset_index()
sortedDf = sortedDf.sort_values(by=['SettlementPoint','Date'])

#splitting the DF into a list of DF's by settlement point
settlementList = sortedDf['SettlementPoint'].unique()

#TODO I was unable to get this exercise but here is my progress I made
#looping through each settlement
for item in settlementList:
    #creating a dataframe for the selected settlement
    settlementDf = sortedDf[sortedDf['SettlementPoint'] == item]
    settlementDf = settlementDf.reset_index(drop=True)

    #creating a template dataframe to place values into
    formattedDf = pd.DataFrame(columns=['Variable','Date','X1','X2','X3','X4','X5','X6','X7','X8','X9','X10','X11','X12','X13','X14','X15','X16','X17','X18','X19','X20','X21','X22','X23','X24'])
    #looping as long as there are values in the data frame
    while settlementDf.empty == False:
        #removing the first day's worth of data
        if settlementDf.size < 24:
            tempDf = settlementDf
        else:    
            tempDf = settlementDf.iloc[:24]
            settlementDf = settlementDf.iloc[24:]
            settlementDf = settlementDf.reset_index(drop=True)
        #pulling the date and settlement name for that day's data
        tempDate = tempDf['Date'][0]
        tempSettlement = tempDf['SettlementPoint'][0]
        #trimming the data until it is just the prices
        tempDf = tempDf.drop('Date',axis=1)
        tempDf = tempDf.drop('SettlementPoint',axis=1)
        #converting the prices to a list and adding in the settlement and date
        priceList = tempDf['Price'].tolist()
        priceList.insert(0,tempDate)
        priceList.insert(0,tempSettlement)
        priceList = pd.Series(priceList)
        #print(priceList)
        #appending the new row to the dataframe to be placed into the frame that will be written to the csv
        formattedDf = pd.concat([formattedDf,priceList],axis=1,ignore_index=True)
    formattedDf = formattedDf.drop(columns=[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25])
    formattedDf = formattedDf.T
    formattedDf = formattedDf.rename(columns={
        0: 'Variable',
        1: 'Date',
        2: 'X1',
        3: 'X2',
        4: 'X3',
        5: 'X4',
        6: 'X5',
        7: 'X6',
        8: 'X7',
        9: 'X8',
        10: 'X9',
        11: 'X10',
        12: 'X11',
        13: 'X12',
        14: 'X13',
        15: 'X14',
        16: 'X15',
        17: 'X16',
        18: 'X17',
        19: 'X18',
        20: 'X19',
        21: 'X20',
        22: 'X21',
        23: 'X22',
        24: 'X23',
        25: 'X24'
    })
    pd.DataFrame.to_csv(formattedDf, f'C:\\Users\\jmreu\\OneDrive\\Desktop\\cQuant Exam\\cQuantExam\\formattedSpotHistory\\spot_{tempSettlement}.csv', index=False)
